export const cyan = '#0089cf'
export const darkBlue = '#0d004c'
export const black = '#222'
export const teal = '#3c6485'
export const burgundy = '#83004c'
export const aqua = '#28c3c6'
export const lightBlue = '#cfe3f1'



export default {
  cyan,
  darkBlue,
  black,
  teal,
  aqua,
  burgundy,
  lightBlue,
}
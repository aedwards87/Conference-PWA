import React from 'react';
import styled from 'styled-components'
import { Link } from "@reach/router";
import isActive from './isActive'

import { aqua, teal } from '../Utilities/index'



const NavMenu = ({ on, toggle }) => (
    <StyledNavWrappper
        className={on ? 'active' : null}
    > 
        <nav>
            <div>
                <Link 
                    exact 
                    to="/" 
                    getProps={isActive} 
                    onClick={toggle} 
                >
                    Home
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/programme" 
                    getProps={isActive} 
                    onClick={toggle} 
                >
                    Programme
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/speakers" 
                    getProps={isActive} 
                    onClick={toggle} 
                >
                    Speakers
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/exhibitors" 
                    getProps={isActive} 
                    onClick={toggle} 
                >
                    Exhibitors
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/video" 
                    getProps={isActive} 
                    onClick={toggle} 
                >
                    The Experience
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/venue-map" 
                    getProps={isActive}
                    onClick={toggle} 
                >
                    Map
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/about" 
                    getProps={isActive}
                    onClick={toggle} 
                >
                    About
                </Link>
            </div>
            <div>
                <Link 
                    exact 
                    to="/contact" 
                    getProps={isActive}
                    onClick={toggle} 
                >
                    Contact
                </Link>
            </div>
        </nav>
    </StyledNavWrappper>
)

const StyledNavWrappper = styled.nav`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: -50px;
    width: 100%;
    height: cal(100% - 55px);
    padding-top: 30px;
    z-index: 99998;
    background: ${teal};
    clip-path: circle(0px at 101% 94vh);
    transition: all .6s ease;
    &.active {
        clip-path: circle(100% at 30% 50vh);
    }
    > nav {
        display: grid;
        align-content: center;
        padding: 0;
        margin: 0;
    }
    > nav div {
        display: grid;
        justify-items: center;
    }
    > nav div a {
        display: grid;
        align-items: center;
        align-content: center;
        justify-content: start;
        height: 100%;
        width: calc(100% - 20px);
        padding: 20px;
        padding-left: 50px;
        font-weight: 400;
        color: white;
        text-decoration: none;
        @media (max-height: 600px) {
            padding-top: 15px;
            padding-bottom: 15px;
        }
    }
    > nav div a:hover {
        color: white;
        background: ${aqua};
        border-radius: 30px;
        font-weight: 600;
    }
    > nav div a.active {
        color: white;
        border: 3px solid ${aqua};
        border-radius: 30px;
        font-weight: 600;
    }
`

export default NavMenu
import { createGlobalStyle } from 'styled-components'

const GlobalStyle = createGlobalStyle`
    body {
        padding-top: 65px;
    }

    
`

export default GlobalStyle
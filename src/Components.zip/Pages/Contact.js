import React from "react"

import Layout from "../Components/Layout"

const Contact = () => (
  <>
    <h1>Contact</h1>
    <p></p>
  </>
)

export default Contact

import React from "react"

import Layout from "../Components/Layout"

const Video = () => (
  <>
    <h1>The Experience</h1>
    <p></p>
  </>
)

export default Video

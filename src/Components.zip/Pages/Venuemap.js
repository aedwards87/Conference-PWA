import React from "react"


const VenueMap = () => (
  <>
    <h1>Map</h1>
    <p></p>
  </>
)

export default VenueMap

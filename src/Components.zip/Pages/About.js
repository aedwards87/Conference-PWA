import React from "react"

import Layout from "../Components/Layout"

const About = () => (
  <>
    <h1>About</h1>
    <p></p>
  </>
)

export default About

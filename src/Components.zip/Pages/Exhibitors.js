import React from "react"

import Layout from "../Components/Layout"

const Exhibitors = () => (
  <>
    <h1>Exhibitors</h1>
    <p></p>
  </>
)

export default Exhibitors
